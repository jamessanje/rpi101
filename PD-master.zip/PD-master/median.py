import statistics

items = [1,3,6,7,8]

print(statistics.median(map(float,items)))

x = []
n = 10
for i in range(1, n):
    x.append(i)

print(x)
