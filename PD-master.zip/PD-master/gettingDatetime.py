import datetime

now = datetime.datetime.today()

print("Day: " + str(now.year))
print("Month: " + str(now.month))
print(now.day)
print(now.hour)
print(now.minute)
print(now.second)
print(now)




